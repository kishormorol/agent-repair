# Combined statistical reproduction supplement

Anonymous bundle covering every completed study in the paper.

## Scope

This bundle reproduces **packaged statistics from packaged trial exports**:
per-condition means, primary contrast point estimates, and the Holm adjustment
within each declared family. Three environments are deliberately separate:

| Environment | Covered here | What it needs |
| --- | --- | --- |
| Statistical reproduction | **yes** | Python, numpy, pandas |
| Raw replay and reference scoring | no | frozen raw trajectories and dataset files |
| GPU regeneration of trajectories | no | the pinned model weights and a GPU |

Reproducing the statistics does not re-derive the trial outcomes; it checks
that the reported statistics follow from the exported trials.

## Contents

One directory per study, each with `trials.csv` (the exported per-trial rows)
and `analysis.json` (the reference analysis). `metrics.py` holds the bootstrap
and Holm routines. `manifest.json` lists a SHA-256 for every file.

## Run

    pip install -r requirements.txt
    python reproduce.py

`reproduce.py` verifies every file against `manifest.json`, recomputes each
study's condition means and contrast deltas from its `trials.csv`, recomputes
the Holm adjustment over each declared family, and writes `verification.json`.
It exits non-zero if any packaged file was altered or any value disagrees.

## Families

| Study | Primary tests | Trial rows |
| --- | --- | --- |
| Main HotpotQA study | 4 | 2,034 |
| Diagnosis and allowance follow-up | 6 | 3,186 |
| Two-model, three-dataset replication | 24 | 8,016 |
| Length-matched swap, Qwen | 2 | 738 |
| Length-matched swap, Mistral | 2 | 1,098 |

No file here reads an absolute workspace path, and no step contacts a network
or cloud account.
