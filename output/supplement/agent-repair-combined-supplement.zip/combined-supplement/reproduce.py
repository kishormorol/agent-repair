"""Reproduce the packaged statistics locally; no cloud or network access."""
import hashlib
import json
import math
import re
from pathlib import Path

import pandas as pd

from metrics import holm_correction

BASE = Path(__file__).resolve().parent
TOLERANCE = 1e-9


def close(a, b, tolerance=TOLERANCE):
    return a is not None and b is not None and math.isclose(a, b, rel_tol=0, abs_tol=tolerance)


def check_manifest():
    manifest = json.loads((BASE / "manifest.json").read_text())
    for name, digest in manifest["sha256"].items():
        actual = hashlib.sha256((BASE / name).read_bytes()).hexdigest()
        if actual != digest:
            raise SystemExit(f"Checksum mismatch: {name}")
    return manifest


def contrasts_of(analysis, key):
    """Return (key, contrast) pairs; a dict key can carry the partition value."""
    container = analysis[key]
    if isinstance(container, dict):
        return list(container.items())
    return [(None, contrast) for contrast in container]


def study_means(trials, contrast, name=None, key_filter=None):
    """Recompute each arm's equal-weight mean from the packaged trial rows."""
    frame = trials
    for column in ["model_key", "dataset"]:
        if column in contrast and column in frame.columns:
            frame = frame[frame[column] == contrast[column]]
    if key_filter and name is not None:
        match = re.search(key_filter["pattern"], name)
        if match is None:
            raise SystemExit(f"Contrast key {name!r} does not match its declared filter")
        frame = frame[frame[key_filter["column"]] == float(match.group(1))]
    if "mode" in frame.columns and "deadline_s" not in contrast:
        frame = frame[frame["mode"] == "token"]
    outcome = contrast.get("outcome", "success")
    if outcome not in frame.columns:
        return None, None
    per = frame.groupby(["strategy", "qid"])[outcome].mean().unstack(0)
    a, b = contrast["strategy_a"], contrast["strategy_b"]
    if a not in per.columns or b not in per.columns:
        return None, None
    paired = per[[a, b]].dropna()
    return float(paired[a].mean()), float(paired[b].mean())


def main():
    manifest = check_manifest()
    report = {"status": "passed", "tolerance": TOLERANCE, "studies": {},
              "scope": "statistical reproduction from packaged trial exports"}
    for study, spec in sorted(manifest["studies"].items()):
        trials = pd.read_csv(BASE / study / "trials.csv")
        analysis = json.loads((BASE / study / "analysis.json").read_text())
        contrasts = contrasts_of(analysis, spec["contrasts"])
        if len(contrasts) != spec["family"]:
            raise SystemExit(f"{study}: expected {spec['family']} primary tests, found {len(contrasts)}")
        if len(trials) != spec["rows"]:
            raise SystemExit(f"{study}: expected {spec['rows']} trial rows, found {len(trials)}")

        means_checked = 0
        for name, contrast in contrasts:
            mean_a, mean_b = study_means(trials, contrast, name, spec.get("key_filter"))
            if mean_a is None:
                continue
            if not (close(mean_a, contrast["mean_a"]) and close(mean_b, contrast["mean_b"])):
                raise SystemExit(f"{study}: condition means differ for "
                                 f"{contrast['strategy_a']} vs {contrast['strategy_b']}")
            if not close(mean_a - mean_b, contrast["delta"]):
                raise SystemExit(f"{study}: delta differs for "
                                 f"{contrast['strategy_a']} vs {contrast['strategy_b']}")
            means_checked += 1

        adjusted = holm_correction([c["p_value"] for _, c in contrasts])
        for (_, contrast), value in zip(contrasts, adjusted):
            reported = contrast.get("p_value_holm")
            if reported is not None and not close(float(reported), float(value)):
                raise SystemExit(f"{study}: Holm adjustment differs for "
                                 f"{contrast['strategy_a']} vs {contrast['strategy_b']}")
        report["studies"][study] = {"primary_tests": len(contrasts), "trial_rows": len(trials),
                                    "contrast_means_recomputed": means_checked,
                                    "holm_family_recomputed": True}
    (BASE / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
